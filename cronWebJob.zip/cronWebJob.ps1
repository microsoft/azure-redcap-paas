#
# cronWebJob.ps1
#

Invoke-WebRequest -Uri "https://$($env:WEBSITE_HOSTNAME)/cron.php" -Method Get

